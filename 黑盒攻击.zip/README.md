## Adversarial Speech Commands

### Setup

Download datset

```
bash download_dataset.sh
```

Download model:

```
bash download_checkpoint.sh
```

### Attack Experiment

To run:

```
./run_attack.sh dataset_dir ckpts_dir limit max_iters test_size
```
